<?php
include_spip('inc/presentation');
?>

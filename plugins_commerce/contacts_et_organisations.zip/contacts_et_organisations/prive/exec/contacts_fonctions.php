<?php
include_spip('inc/presentation'); // onglet
include_spip('inc/boutons'); // barre_onglets
?>

-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Mer 20 Juin 2012 à 18:31
-- Version du serveur: 5.5.16
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `spip3p3`
--

-- --------------------------------------------------------

--
-- Structure de la table `spip_rubriques`
--

DROP TABLE IF EXISTS `spip_rubriques`;
CREATE TABLE IF NOT EXISTS `spip_rubriques` (
  `id_rubrique` bigint(21) NOT NULL AUTO_INCREMENT,
  `id_parent` bigint(21) NOT NULL DEFAULT '0',
  `titre` text NOT NULL,
  `descriptif` text NOT NULL,
  `texte` longtext NOT NULL,
  `id_secteur` bigint(21) NOT NULL DEFAULT '0',
  `maj` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `statut` varchar(10) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lang` varchar(10) NOT NULL DEFAULT '',
  `langue_choisie` varchar(3) DEFAULT 'non',
  `statut_tmp` varchar(10) NOT NULL DEFAULT '0',
  `date_tmp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `profondeur` smallint(5) NOT NULL DEFAULT '0',
  `composition` varchar(255) NOT NULL DEFAULT '',
  `composition_lock` tinyint(1) NOT NULL DEFAULT '0',
  `composition_branche_lock` tinyint(1) NOT NULL DEFAULT '0',
  `agenda` tinyint(1) NOT NULL DEFAULT '0',
  `id_trad` bigint(21) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_rubrique`),
  KEY `lang` (`lang`),
  KEY `id_parent` (`id_parent`),
  KEY `id_trad` (`id_trad`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Contenu de la table `spip_rubriques`
--

INSERT INTO `spip_rubriques` (`id_rubrique`, `id_parent`, `titre`, `descriptif`, `texte`, `id_secteur`, `maj`, `statut`, `date`, `lang`, `langue_choisie`, `statut_tmp`, `date_tmp`, `profondeur`, `composition`, `composition_lock`, `composition_branche_lock`, `agenda`, `id_trad`) VALUES
(1, 0, 'Accueil', '', '', 1, '2012-06-20 13:08:59', 'publie', '2012-06-20 15:08:59', 'fr', 'non', '0', '0000-00-00 00:00:00', 0, 'articles_recents', 0, 0, 0, 1),
(2, 1, '1. Qui sommes nous ?', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas mauris dui, scelerisque nec tempus id, adipiscing sit amet risus. Integer laoreet purus sit amet magna varius sit amet pellentesque neque pretium. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pulvinar gravida tellus non rutrum. Quisque sit amet dui ac magna porttitor pulvinar at a orci. Etiam accumsan sodales vulputate. Sed tincidunt dictum libero. Integer vitae lacinia magna. Duis eget nisl non ipsum mattis pulvinar. Suspendisse potenti. Integer vehicula tempus augue vitae mattis. Sed fringilla eleifend viverra. Ut hendrerit vulputate turpis ut convallis. \r\n\r\n Vestibulum nisi elit, feugiat non suscipit sit amet, tincidunt eu risus. Cras ante odio, volutpat at dictum et, eleifend ac justo. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In rutrum ipsum ac arcu porta a aliquet dolor porta. Praesent in arcu magna. Proin ut justo est, in egestas risus. Curabitur varius malesuada est sed malesuada. Vestibulum eget justo felis. Aenean semper, orci sit amet venenatis bibendum, massa neque volutpat dolor, a sodales risus orci id diam.', 1, '2012-06-06 16:05:38', 'new', '0000-00-00 00:00:00', 'fr', 'non', '0', '0000-00-00 00:00:00', 1, '', 0, 0, 0, 2),
(3, 1, '2. Boutique', '', '', 1, '2012-06-20 13:08:59', 'publie', '2012-06-20 15:08:59', 'fr', 'non', '0', '0000-00-00 00:00:00', 1, 'liste_produits', 1, 1, 0, 3),
(4, 1, '5. Contact', '', '', 1, '2012-06-06 17:12:29', 'new', '0000-00-00 00:00:00', 'fr', 'non', '0', '0000-00-00 00:00:00', 1, 'fomulaire_contact', 1, 1, 0, 4),
(5, 1, '3. Nouvelles', '', '', 1, '2012-06-06 16:09:40', 'publie', '2012-06-01 18:22:26', 'fr', 'non', '0', '0000-00-00 00:00:00', 1, 'articles_rubrique', 0, 0, 0, 5),
(6, 0, 'Home', '', '', 6, '2012-06-14 16:00:27', 'publie', '2012-06-14 18:00:27', 'en', 'oui', '0', '0000-00-00 00:00:00', 0, 'articles_recents', 1, 0, 0, 1),
(7, 6, '1. Who are we?', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce hendrerit tempus justo ut gravida. Praesent aliquam augue sed ipsum ornare porttitor. Aliquam fermentum velit eget lectus hendrerit porta. Quisque rutrum quam eu lectus congue viverra. Ut eget mi in orci euismod luctus et id nulla. Nullam accumsan luctus lacus, id dictum sem volutpat egestas. Nunc porttitor dignissim ligula. Cras vulputate porttitor urna, eget rhoncus sapien rhoncus sed. Nullam euismod faucibus erat in laoreet. Curabitur elementum sollicitudin eros, lobortis mollis nisl posuere vitae. Cras enim lorem, tempor eget rhoncus sed, fringilla pulvinar elit. Sed aliquam mi vel risus dapibus ac aliquam nisi accumsan. Donec nec libero lobortis nibh convallis porttitor et vel est. Ut felis nibh, congue eu malesuada accumsan, congue id mauris. \r\n\r\n Nulla quis magna ipsum. Phasellus consectetur vehicula aliquam. Aliquam id sapien eros, id porta arcu. Ut felis libero, varius eget tincidunt nec, suscipit in justo. Mauris vehicula, elit vitae faucibus sollicitudin, sapien urna vulputate sapien, nec semper massa nisl quis metus. Quisque cursus nisi ac libero volutpat ut iaculis tellus pretium. Aenean diam augue, commodo et facilisis non, laoreet vitae neque. Vivamus ullamcorper orci in eros sodales eu fermentum magna vehicula. Integer at dui in elit condimentum mollis. Quisque eros risus, sagittis eu dignissim ac, tincidunt ac magna. Donec nulla est, elementum id fermentum sit amet, commodo ac massa. In sed arcu sed neque adipiscing pulvinar. Donec eu orci nibh, fermentum pulvinar ligula. Phasellus facilisis sem vitae orci feugiat posuere. Fusce quis nunc turpis.', 6, '2012-06-08 14:03:56', 'new', '0000-00-00 00:00:00', 'en', 'oui', '0', '0000-00-00 00:00:00', 1, '', 1, 0, 0, 2),
(8, 6, '2. Shop', '', '', 6, '2012-06-15 14:12:56', '0', '2012-06-14 18:00:27', 'en', 'oui', '0', '0000-00-00 00:00:00', 1, 'galerie', 1, 0, 0, 3),
(9, 6, '3. News', '', '', 6, '2012-06-06 17:11:25', 'publie', '2012-06-06 18:56:44', 'en', 'oui', '0', '0000-00-00 00:00:00', 1, 'articles_rubrique', 1, 0, 0, 5),
(10, 6, '5. Contact', '', '', 6, '2012-06-13 09:44:33', 'new', '0000-00-00 00:00:00', 'en', 'oui', '0', '0000-00-00 00:00:00', 1, 'fomulaire_contact', 0, 0, 0, 4),
(11, 1, '4. Agenda', '', '', 1, '2012-06-07 17:37:50', 'publie', '2012-06-06 19:15:03', 'fr', 'non', '0', '0000-00-00 00:00:00', 1, 'agenda', 0, 0, 1, 11),
(12, 6, '4. Agenda', '', '', 6, '2012-06-07 17:53:58', '0', '2012-06-06 19:15:00', 'en', 'oui', '0', '0000-00-00 00:00:00', 1, 'agenda', 0, 0, 1, 11),
(14, 0, 'Beginpagina', '', '', 14, '2012-06-08 15:07:13', 'publie', '2012-06-08 17:02:57', 'nl', 'oui', '0', '0000-00-00 00:00:00', 0, 'articles_recents', 1, 0, 0, 1),
(15, 14, '1. Wie zijn wij?', '', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas mauris dui, scelerisque nec tempus id, adipiscing sit amet risus. Integer laoreet purus sit amet magna varius sit amet pellentesque neque pretium. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pulvinar gravida tellus non rutrum. Quisque sit amet dui ac magna porttitor pulvinar at a orci. Etiam accumsan sodales vulputate. Sed tincidunt dictum libero. Integer vitae lacinia magna. Duis eget nisl non ipsum mattis pulvinar. Suspendisse potenti. Integer vehicula tempus augue vitae mattis. Sed fringilla eleifend viverra. Ut hendrerit vulputate turpis ut convallis. \r\n\r\n Vestibulum nisi elit, feugiat non suscipit sit amet, tincidunt eu risus. Cras ante odio, volutpat at dictum et, eleifend ac justo. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In rutrum ipsum ac arcu porta a aliquet dolor porta. Praesent in arcu magna. Proin ut justo est, in egestas risus. Curabitur varius malesuada est sed malesuada. Vestibulum eget justo felis. Aenean semper, orci sit amet venenatis bibendum, massa neque volutpat dolor, a sodales risus orci id diam.', 14, '2012-06-08 14:53:35', 'new', '0000-00-00 00:00:00', 'nl', 'oui', '0', '0000-00-00 00:00:00', 1, '', 0, 0, 0, 2),
(16, 14, ' 2. Winkel', '', '', 14, '2012-06-15 14:13:01', '0', '2012-06-08 17:00:24', 'nl', 'oui', '0', '0000-00-00 00:00:00', 1, 'galerie', 0, 0, 0, 3),
(17, 14, '3. Nieuws', '', '', 14, '2012-06-08 15:04:41', 'publie', '2012-06-08 17:02:57', 'nl', 'oui', '0', '0000-00-00 00:00:00', 1, 'articles_rubrique', 1, 0, 0, 5),
(18, 14, '4. Agenda', '', '', 14, '2012-06-08 15:05:19', 'new', '0000-00-00 00:00:00', 'nl', 'oui', '0', '0000-00-00 00:00:00', 1, 'agenda', 1, 0, 0, 11),
(19, 14, '5. Contact', '', '', 14, '2012-06-08 15:05:52', 'new', '0000-00-00 00:00:00', 'nl', 'oui', '0', '0000-00-00 00:00:00', 1, 'fomulaire_contact', 1, 0, 0, 4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
